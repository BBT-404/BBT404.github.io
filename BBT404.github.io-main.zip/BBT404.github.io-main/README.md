This is a webpage intended to showcase my work.
I take pride in having made this website myself, mainly off the back of my A-Level HTML and CSS learnings, but also spurred along by resources like those of w3schools[1].
If you can't get to the website, use this link (https://bbt-404.github.io/BBT404.github.io/)


External Attributions:
[1] w3schools resources
  a) Grids: https://www.w3schools.com/css/css_grid.asp
  b) 
